package config;

public class Config {

    public static final String serviceIp = "192.168.1.112";

    public static final String xServiceIp = "localhost";

}
